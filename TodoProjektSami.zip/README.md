# Todo-Projekt
Dies ist ein Projekt dass dem Benutzer erlaubt, seine Todos aufzuschreiben und zu speichern auf einem lokalen Server.

## Programmier Sprachen
Diese Web Applikation wurde in HTML, CSS und vorallem in JavaScript geschrieben.

## Bedingungen
* Dieses Repo clonen
* Es mit `LiveServer Extension VSCode` öffnen.
* Backend herunterladen: <a href="dummy">Link zum Download</a>.
Wenn das alles erledigt ist, schreiben Sie die folgenden Commands in ihren Terminal-Emulator:
* ```cd backend```
* ```npm install```
* ```npm start```

# Authoren
* Sami Hindi

# Testfälle
<a href="Testfaelle.md">Testfälle</a>